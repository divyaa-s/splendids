document.addEventListener('DOMContentLoaded', function () {
    const cartItems = document.getElementById('cart-items');
    const totalPriceElement = document.getElementById('total-price');

    const cart = [];

    window.addToCart = function (productName, productPrice) {
        const cartItem = { name: productName, price: productPrice };
        cart.push(cartItem);

        // Update cart display
        renderCart();

        // Update total price
        updateTotalPrice();
    };

    window.removeFromCart = function (index) {
        cart.splice(index, 1);

        // Update cart display
        renderCart();

        // Update total price
        updateTotalPrice();
    };

    window.checkout = function () {
        alert('Thank you for your purchase!');
        cart.length = 0; // Clear the cart
        renderCart(); // Update cart display
        updateTotalPrice(); // Update total price
    };

    function renderCart() {
    cartItems.innerHTML = '';
    cart.forEach((item, index) => {
        const cartItemElement = document.createElement('li');
        cartItemElement.innerHTML = `
            ${item.name} - ₹${item.price.toFixed(2)}
            <button onclick="removeFromCart(${index})">Remove from Cart</button>
        `;
        cartItems.appendChild(cartItemElement);
    });
}


    function updateTotalPrice() {
        const totalPrice = cart.reduce((total, item) => total + item.price, 0);
        totalPriceElement.textContent = totalPrice.toFixed(2);
    }


});
